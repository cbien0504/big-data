from pyspark.sql import SparkSession
spark = SparkSession.builder \
    .appName('HDFSToElasticSearch') \
    .config('spark.hadoop.hadoop.security.authentication', 'simple') \
    .config("spark.es.nodes", "elasticsearch") \
    .config("spark.es.port", 9200) \
    .config("spark.jars", "/es/elasticsearch-hadoop-7.13.1.jar, /es/scala-library-2.12.10.jar")
    .config("spark.jars.packages", "org.apache.httpcomponents:httpclient:4.5.14") \
    .config("spark.es.index.auto.create", "true") \
    .getOrCreate()
print(spark.version)
df = spark.read.format("json").load("data.json")
df.printSchema()

df.write.format("org.elasticsearch.spark.sql")\
    .option("es.nodes", "http://elasticsearch:9200")\
    .option("es.nodes.discovery", "false")\
    .option("es.nodes.wan.only", "true")\
    .option("es.index.auto.create", "true")\
    .option("es.mapping.id", "_id")\
    .option("es.mapping.exclude", "_id")\
    .save("tweets")

print("DataFrame written successfully to Elasticsearch.")